# Book Theme

> [!NOTE]
> This repository contains the _build artifacts_ that comprise the MyST Book Theme. To report an bug or request a feature, please see the [upstream themes repo](https://github.com/executablebooks/myst-theme).
